using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO.Pipes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace App_Server
{
    public partial class FormServer : Form
    {
        private ConcurrentDictionary<string, NamedPipeServerStream> clients = new();
        private System.Windows.Forms.Timer pingTimer;

        public FormServer()
        {
            InitializeComponent();
            pingTimer = new System.Windows.Forms.Timer();
            pingTimer.Interval = 5000;
            pingTimer.Tick += PingTimer_Tick;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            buttonStart.Enabled = false;
            Task.Run(() => StartPipeServer());
            pingTimer.Start();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            if (listBoxClients.SelectedItem != null)
            {
                string selectedClientId = listBoxClients.SelectedItem.ToString();
                if (clients.TryGetValue(selectedClientId, out var server))
                {
                    Send(server, textBoxOutput.Text);
                }
            }
            else
            {
                SendToAll(textBoxOutput.Text);
            }
        }

        private void PingTimer_Tick(object sender, EventArgs e)
        {
            SendToAll("Ping");
        }

        private void StartPipeServer()
        {
            while (true)
            {
                var server = new NamedPipeServerStream("Server511", PipeDirection.InOut, NamedPipeServerStream.MaxAllowedServerInstances, PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
                server.WaitForConnection();
                Task.Run(() => HandleClient(server));
            }
        }

        private void HandleClient(NamedPipeServerStream server)
        {
            string clientId = string.Empty;
            try
            {
                byte[] buffer = new byte[256];
                int bytesRead = server.Read(buffer, 0, buffer.Length);
                clientId = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                clients.TryAdd(clientId, server);
                Invoke(new Action(() => listBoxClients.Items.Add(clientId)));

                while (server.IsConnected)
                {
                    bytesRead = server.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break;

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Invoke(new Action(() => textBoxInput.Text += $"[{clientId}]: {message}" + Environment.NewLine));
                }
            }
            catch (Exception) { }
            finally
            {
                if (!string.IsNullOrEmpty(clientId))
                {
                    clients.TryRemove(clientId, out _);
                    Invoke(new Action(() => listBoxClients.Items.Remove(clientId)));
                }
                server?.Dispose();
            }
        }

        private void Send(NamedPipeServerStream server, string message)
        {
            if (!string.IsNullOrEmpty(message) && server.IsConnected)
            {
                try
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(message);
                    server.Write(bytes, 0, bytes.Length);
                }
                catch { }
            }
        }

        private void SendToAll(string message)
        {
            foreach (var client in clients.Values)
            {
                Send(client, message);
            }
        }
    }
}