﻿namespace App_Server
{
    partial class FormServer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonStart = new Button();
            textBoxInput = new TextBox();
            textBoxOutput = new TextBox();
            button2 = new Button();
            listBoxClients = new ListBox();
            SuspendLayout();
            // 
            // buttonStart
            // 
            buttonStart.Location = new Point(20, 19);
            buttonStart.Margin = new Padding(5, 5, 5, 5);
            buttonStart.Name = "buttonStart";
            buttonStart.Size = new Size(153, 46);
            buttonStart.TabIndex = 0;
            buttonStart.Text = "Start";
            buttonStart.UseVisualStyleBackColor = true;
            buttonStart.Click += buttonStart_Click;
            // 
            // textBoxInput
            // 
            textBoxInput.Location = new Point(20, 93);
            textBoxInput.Margin = new Padding(5, 5, 5, 5);
            textBoxInput.Multiline = true;
            textBoxInput.Name = "textBoxInput";
            textBoxInput.ReadOnly = true;
            textBoxInput.Size = new Size(669, 329);
            textBoxInput.TabIndex = 1;
            // 
            // textBoxOutput
            // 
            textBoxOutput.Location = new Point(20, 434);
            textBoxOutput.Margin = new Padding(5, 5, 5, 5);
            textBoxOutput.Name = "textBoxOutput";
            textBoxOutput.Size = new Size(506, 39);
            textBoxOutput.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(538, 434);
            button2.Margin = new Padding(5, 5, 5, 5);
            button2.Name = "button2";
            button2.Size = new Size(153, 46);
            button2.TabIndex = 3;
            button2.Text = "Send";
            button2.UseVisualStyleBackColor = true;
            button2.Click += buttonSend_Click;
            // 
            // listBoxClients
            // 
            listBoxClients.FormattingEnabled = true;
            listBoxClients.Location = new Point(739, 93);
            listBoxClients.Name = "listBoxClients";
            listBoxClients.Size = new Size(240, 164);
            listBoxClients.TabIndex = 4;
            // 
            // FormServer
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1027, 496);
            Controls.Add(listBoxClients);
            Controls.Add(button2);
            Controls.Add(textBoxOutput);
            Controls.Add(textBoxInput);
            Controls.Add(buttonStart);
            Margin = new Padding(5, 5, 5, 5);
            Name = "FormServer";
            Text = "Server";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonStart;
        private TextBox textBoxInput;
        private TextBox textBoxOutput;
        private Button button2;
        private ListBox listBoxClients;
    }
}
